#include "Paciente.hpp"

Paciente::Paciente()
{
    this->generarDNI();
    this->apendicitis = (rand() % 2);
    id = 0;
    habitacion = 0;
}

Paciente::~Paciente()
{
}

void Paciente::generarDNI()
{
    char letras[] = "TRWAGMYFPDXBNJZSQVHLCKE";
    int numDNI = 0, aux = 1E7;
    for(int i = 0; i < 8; i++) {
        int num = rand() % 10;
        this->dni[i] = '0' + num;
        numDNI = numDNI + num * aux;
        aux /= 10;
    }
    this->dni[8] = letras[numDNI % 23];
    this->dni[9] = '\0';
}

bool Paciente::tieneApendicitis()
{
    return apendicitis;
}

int Paciente::getId()
{
    return id;
}

int Paciente::getHabitacion()
{
    return habitacion;
}

void Paciente::setId(int nuevoId)
{
    id = nuevoId;
}

void Paciente::setHabitacion(int nuevaHab)
{
    habitacion = nuevaHab;
}

void Paciente::mostrar()
{
    cout << "\tEl paciente cuyo DNI es " << dni << " tiene "
         << (apendicitis ? "apendicitis" : "hernias");

    if (id != 0 && habitacion != 0) {
        cout << ", su ID es: " << id << " y su habitacion asignada es: " << habitacion;
    }
    cout << endl;
}